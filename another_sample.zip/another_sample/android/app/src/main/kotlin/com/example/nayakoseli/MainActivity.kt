package com.example.nayakoseli

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
