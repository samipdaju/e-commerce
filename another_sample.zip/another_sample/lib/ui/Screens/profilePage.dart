import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {


  @override
  Widget build(BuildContext context) {

    return Container(
      child: Center(

        child: Column(

          children: [
            SizedBox(height: 30,),
            CircleAvatar(
              radius: 100,
              backgroundImage: AssetImage("assets/john.jpg"),


            ),
            Text("Samip Paudel",style: TextStyle(
              fontSize: 30,
            ),),
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.fromLTRB(0,20,8,20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.phone),
                  Text("9840728655",style: TextStyle(

                      fontSize: 20
                  ),),
                  Text("Update",style: TextStyle(
                    color: Colors.blue,
                    fontSize: 16
                  ),)
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(0,20,8,20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.email),
                  Text("paudelsamip8988@gmail.com",style: TextStyle(

                      fontSize: 20
                  ),),
                  Text("Update",style: TextStyle(
                      color: Colors.blue,
                      fontSize: 16
                  ),)
                ],
              ),
            ),
            SizedBox(height: 70,),
            Column(

              children: [
                TextButton(
                  onPressed: (){
                    showDialog<String>(
                        context: context,
                        builder: (BuildContext context) => AlertDialog(
                      title: const Text('Are you sure you want to log out?'),

                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.pushReplacementNamed(context, "logIn"),
                          child: const Text('YES',style: TextStyle(
                            fontSize: 18
                          ),),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(context, 'OK'),
                          child: const Text('NO',style: TextStyle(
                              fontSize: 18
                          )),
                        ),
                      ],
                    ),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(  color: Colors.white,
                    borderRadius: BorderRadius.circular(30),

                    ),
                    margin: EdgeInsets.all(15),
                    padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                    child: Center(
                      child: Text("Log Out ",style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w600,
                        color: Colors.brown
                      ),),
                    ),


                  ),
                ),
              ],
            )

          ],
        ),
      ),
    );
  }
}

