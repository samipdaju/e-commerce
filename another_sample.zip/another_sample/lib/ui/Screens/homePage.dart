import 'package:flutter/material.dart';

import 'package:nayakoseli/model/categories.dart';
import 'package:nayakoseli/model/productTypes.dart';
import 'package:nayakoseli/ui/Screens/productDetails%20Screen.dart';
import 'package:nayakoseli/ui/Screens/productScreen.dart';

class HomePage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(

      child: Column(children: [
        SizedBox(
          height: 15,
        ),

        Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "All CATEGORIES",
                    style: TextStyle(
                      fontSize: 22,
                      letterSpacing: 1.5,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Row(
                    children: [
                      Text(
                        "See ALL ",
                        style: TextStyle(
                          fontSize: 16,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      Icon(
                        Icons.arrow_right_alt,
                        color: Colors.blue,
                      )
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              height: 280,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, position) {
                  Categories category = categories[position];
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ProductScreen(
                                    categories: category,
                                  )));
                    },
                    child: Container(

                      decoration: BoxDecoration(),
                      margin: EdgeInsets.all(10),
                      width: 210,
                      child: Stack(
                        alignment: Alignment.topCenter,
                        children: [
                          Positioned(
                            bottom: 20,



                            child: Container(
                              padding: EdgeInsets.fromLTRB(18, 0, 0, 20),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.white,
                              ),
                              width: 200,
                              height: 120,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 18.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      category.category,
                                      style: TextStyle(
                                        fontSize: 30,
                                        color: Colors.black,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black26,
                                      offset: Offset(0, 2.6),
                                      blurRadius: 6,
                                    ),
                                  ]),
                              child: Stack(
                                children: [
                                  Hero(
                                    tag: category.imageUrl,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image(
                                        image: AssetImage(category.imageUrl),
                                        height: 170,
                                        width: 180,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ],
                              ))
                        ],
                      ),
                    ),
                  );
                },
                itemCount: categories.length,
              ),
            ),
            Text(
              "BestSeller",
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: 250,

              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, position) {

                  Products product = bestSeller[position];
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ProductDetailScreen(products: product)));
                    },
                    child: Container(

                      decoration: BoxDecoration(),
                      margin: EdgeInsets.all(10),
                    width: MediaQuery.of(context).size.width-20,
                      child: Stack(
                        children: [
                          Container(
                            padding: EdgeInsets.fromLTRB(140, 5, 10, 5),
                            margin: EdgeInsets.fromLTRB(40, 5, 20, 5),
                            height: 180,
                            width: double.infinity,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black26,
                                    offset: Offset(0, 2),
                                    blurRadius: 6,
                                  )
                                ]),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Container(
                                  child: Text(
                                    product.productName,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 25,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Rs: ${product.rate}",
                                  style: TextStyle(
                                    fontSize: 20,
                                  ),
                                ),
                                TextButton(
                                    onPressed: () {},
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Text(
                                          "Buy Now",
                                        ),
                                        Icon(Icons.shopping_cart)
                                      ],
                                    )),
                              ],
                            ),
                          ),
                          Positioned(
                            left: 10,
                            top: 25,
                            child: Hero(
                              tag:   product.imageUrl,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(20),
                                child: Image(
                                  image: AssetImage(
                                    product.imageUrl,
                                  ),
                                  height: 150,
                                  width: 150,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                itemCount: bestSeller.length,
              ),
            ),
          ],
        )
      ]),
    );
  }
}
