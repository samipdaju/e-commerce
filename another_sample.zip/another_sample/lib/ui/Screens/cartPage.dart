import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:nayakoseli/StateManagementModel/ProductModel.dart';


import 'package:provider/provider.dart';

class CartPage extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 10,
        ),
        Consumer<CartModel>(
          builder: (context, cart, child) {

            return cart.carts != null

                ? Expanded(
                    child: Container(
                      child: ListView.builder(
                        itemBuilder: (context, position) {

                          var product = cart.carts[position];
                          int quantity = product.quantity;
                          int rate = int.parse(product.rate)* quantity ;


                          return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Stack(children: [
                                Container(
                                  padding: EdgeInsets.fromLTRB(140, 5, 10, 5),
                                  margin: EdgeInsets.fromLTRB(40, 5, 20, 5),
                                  height: 130,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      color: Colors.white,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black26,
                                          offset: Offset(0, 2),
                                          blurRadius: 6,
                                        )
                                      ]),
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Container(
                                        child: Text(
                                          product.productName,
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 25,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        "Rs: "
                                        "$rate",
                                        style: TextStyle(
                                          fontSize: 20,
                                        ),
                                      ),
                                      Text(
                                        "Piece: "
                                        "${ product.quantity}",
                                        style: TextStyle(
                                          fontSize: 20,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image(
                                    image: AssetImage(
                                      product.imageUrl,
                                    ),
                                    height: 130,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Positioned(
                                  top: 0,
                                  left: 0,
                                  child: IconButton(
                                    onPressed: () async {
                                      print("Hello");

                                      cart.deleteProductsInCart(position);

                                          cart.decreaseMoney(int.parse(product.rate));
                                    },
                                    icon: Icon(
                                      Icons.close,
                                      size: 35,
                                      color: Colors.red,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  bottom: 10,
                                  left: 0,
                                  child: Row(
                                    children: [
                                      IconButton(
                                        onPressed: () async {

                                          await Provider.of<CartModel>(context,listen: false).update(
                                              image: product.imageUrl,
                                              quantity: product.quantity,
                                              description: product.description,
                                              productName: product.productName,
                                              rate: product.rate,
                                            index: position

                                          );

                                        },
                                        icon: CircleAvatar(
                                          backgroundColor: Colors.black54,
                                          child: Icon(
                                            Icons.add,
                                            size: 25,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () async {

                                          await Provider.of<CartModel>(context,listen: false).updateDecrease(
                                              image: product.imageUrl,
                                              quantity: product.quantity,
                                              description: product.description,
                                              productName: product.productName,
                                              rate: product.rate,
                                              index: position

                                          );
                                        },
                                        icon: CircleAvatar(
                                          backgroundColor: Colors.black54,
                                          child: Icon(
                                            Icons.remove,
                                            size: 25,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ]));
                        },
                        itemCount: cart.carts.length,
                      ),
                    ),
                  )
                : Container();
          },
        ),
        Consumer<CartModel>(builder: (context, cart, child) {
          return Visibility(
            visible: cart.carts.length == 0 ? false : true,
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.green,
              ),
              child: Text(
                "Confirm Order Rs."
                " ${cart.showMoneys().toString()}"
                "",
                style: TextStyle(color: Colors.yellow, fontSize: 20),
              ),
            ),
          );
        })
      ],
    );
  }
}
