import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LogInModel extends ChangeNotifier{

  bool showPassword = true;
  bool showConfirmPassword = true;
  bool showPasswordSignUp = true;


  onTapPassword(){
    showPassword = !showPassword;
    notifyListeners();
  }
  onTapSignUpPassword(){
    showPasswordSignUp = !showPasswordSignUp;
    notifyListeners();
  }

  onTapConfirmPassword(){
    showConfirmPassword = ! showConfirmPassword;
    notifyListeners();
  }


}